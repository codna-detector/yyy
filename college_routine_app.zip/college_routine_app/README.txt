Flutter অ্যাপ - কলেজ রুটিন

কম্পিউটারে Flutter SDK ইনস্টল করা থাকতে হবে (flutter.dev)।

১. এই ফোল্ডারে টার্মিনাল খুলুন
২. flutter create --platforms=android .
৩. flutter pub get
৪. ফোন কানেক্ট করে চালাতে:   flutter run
৫. APK বানাতে:               flutter build apk --release
   ফাইল পাবেন: build/app/outputs/flutter-apk/app-release.apk
   (এটার নাম বদলে collage.apk করে ওয়েবসাইটের ফোল্ডারে রাখুন)

GitHub দিয়ে APK বানানো (কম্পিউটারে কিছু ইনস্টল ছাড়া):
১. github.com-এ নতুন repository বানান
২. এই ফোল্ডারের সব ফাইল (.github সহ) আপলোড করুন
৩. Actions ট্যাব > Build APK > Run workflow
৪. শেষ হলে Artifacts থেকে collage-apk ডাউনলোড করুন (জিপ খুললে collage.apk)
